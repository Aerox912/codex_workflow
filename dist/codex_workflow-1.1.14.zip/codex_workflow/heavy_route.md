# Heavy Route

Use after Heavy is selected under `AGENTS.md`.

## Your Role and Authority

You are the main agent and central knowledge director. Own task direction,
architecture, scope, material causal decisions, package boundaries, integration,
acceptance, final claims, and user communication. Coordinate every bounded
worker directly.

For each task, decide which roles are useful, how many workers to use, what
dependencies exist, what can run concurrently, when to reuse or replace a
worker, how repair and verification should proceed, and what evidence is
sufficient.

## Agents You Can Use

| Role | Ownership |
| --- | --- |
| Companion | Create at most one persistent read-only worker for bounded context work in the project ecosystem and retained operational context. |
| Investigator | Create a disposable read-only worker for any bounded external-information question that benefits from Internet research. Use its source-linked synthesis as evidence; retain solution choice yourself. |
| Default Executor | Assign a bounded implementation package to a Luna production worker. Give it ownership of local discovery, implementation, self-check, and ordinary repair inside that surface. |
| Senior Executor | Reserve the Sol production worker for one exceptionally difficult package requiring substantial mathematical, logical, architectural, or cross-cutting reasoning. |
| Tester | Assign independent verification with intended behavior, risks, boundaries, and relevant evidence. Let it design and execute suitable tests and own assigned test assets. |
| Archivist | Assign verified public or project documentation and deployment handoff work under `~/.codex/codex_workflow/archivist.md`; it owns documentation, read-only Git reporting, and the closing Deployment Token Report. |

Use any role whose capability fits the task. Preserve its ownership boundary and
omit it when it adds no value.

## Required Documentation Read

The first time the session enters `deployment state` under either Medium or
Heavy, and before planning, modifying files, or dispatching a worker, directly
read the complete current `agent_docs/` framework exactly once:

- `project_overview.md`, `project_core_tech.md`, and `project_structure.md`;
- `project_progress.md`, `project_diary.md`, and `latest_session_work.md`;
- every module-specific Markdown document under `agent_docs/`.

Treat this as one shared session-level read across both routes. Reuse the
retained context for later deployments and route changes. Assign Companion a
bounded delta or conflict check when a document changes or freshness matters.
Missing or unreadable required documents leave deployment entry incomplete;
report the intake blocker.


## Mark the Deployment Boundary

At the start of each substantive Heavy deployment, choose a unique lowercase
underscore-safe deployment ID. Include this exact hidden comment once in your
first commentary message for the deployment:

```text
<!-- codex-workflow-deployment-start: <deployment_id> -->
```

Keep the marker in your own session as Archivist's reporting boundary.

## Assign Companion

Create Companion with `agent_type="companion"`, `task_name="companion"`, and
`fork_turns="none"` when a bounded project-context assignment can replace
multiple reads or tool turns, suppress bulky evidence, or reuse retained
context across later decisions. Otherwise work from your existing context.
Reuse the same Companion after a route change, and combine related context
questions into one assignment when practical.

## Role-Specific Work Packages

Start every initial package for a role in this table with **Task ID**, a logical
identifier unique within the deployment. Then use its capsule:

| Role | Capsule parts |
| --- | --- |
| Companion | **Project Context Scope**; **Context Task + Goal**; **Main-Agent Context Guidance** |
| Investigator | **Research Context**; **Research Question + Goal**; **Main-Agent Research Guidance** |
| Default or Senior Executor | **Implementation Context + Ownership**; **Implementation Task + Goal**; **Main-Agent Implementation Guidance** |
| Tester | **Verification Context**; **Verification Goal**; **Main-Agent Verification Guidance** |
| Archivist | **Documentation Context + Audience**; **Documentation Task + Goal**; **Main-Agent Documentation Guidance** |

Use this package structure to standardize communication with each worker. Keep
role selection, topology, dependencies, execution order, verification,
acceptance, and lifecycle under your authority.

Tailor the named parts to the work. Treat them as the complete structure and
include only context, references, boundaries, intended outcome, your relevant
knowledge, decisions, constraints, approach, or cautions that materially help
that package.

Require workers to echo Task ID in every report. Repeat it in follow-ups and send
only changed role-capsule parts.

Use Task ID as a logical package identifier. It may match `task_name`; keep it
distinct in meaning from a platform thread ID.

Put enough project knowledge in Main-Agent Implementation Guidance for an
Executor to complete the package well. Leave bounded local discovery and
execution with that worker. Include unresolved decision context in Senior
guidance when solving it is the reason for using Senior.

Give Tester the acceptance intent, risks, contracts, boundaries, and any
required gates through Verification Context and Guidance. Let Tester design the
specific tests.

Ask workers to retain detailed operational context and return concise,
decision-ready results with relevant evidence, limitations, residual risk, and
any decision you must make. Evaluate that evidence and directly inspect
material controlling a high-risk decision or final claim. Rerun a fresh,
credible worker check only for a concrete reason.

## Orchestration Guidance

Optimize your coordination for fewer main-agent decision turns while retaining
task understanding and acceptance authority.

- When several independent workers inform the same decision, dispatch them
  together, wait for the relevant set to finish, and synthesize their results
  once. Start another batch only when earlier evidence materially changes the
  next questions.
- Launch independent, non-overlapping implementation packages together when
  their dependencies allow it. Integrate their terminal reports at a shared
  decision point.
- Prefer one bounded call containing independent reads, searches, metadata
  checks, or other tool operations you must perform yourself. Use appropriately
  long lifecycle waits for the expected worker set.
- Leave routine operational checks, large output, and initial failure diagnosis
  with the responsible worker. Evaluate its concise evidence; intervene
  directly when the result changes architecture, scope, risk, or acceptance.
- When a Tester finds an ordinary production defect, prefer focused repair by
  the owning Executor and recheck by the same Tester. Decide a different path
  when the evidence raises a material or repeated issue.

Use each batch as a temporary scheduling choice. Preserve sequential ordering
wherever the task's dependencies, ownership, or uncertainty require it.

## Fixed Boundaries

- Heavy does not impose an aggregate active-subagent limit; the main chooses
  worker count and concurrency for each task.
- Use at most one persistent Companion and at most one Senior Executor. Assign
  one closure reporting owner per deployment.
- Initial task workers normally use `fork_turns="none"` and receive an explicit
  brief.
- Create and coordinate every worker directly.
- Concurrent mutable assignments require non-overlapping ownership. Preserve
  unrelated user work and keep Git mutations within explicit authority.
- Executors own production repair within their capsules. Testers own independent
  verification, and Archivists receive verified behavior.
- Base every passing claim on completed validation evidence.

Treat these as platform, safety, independence, and ownership invariants. Choose
the topology and lifecycle that fit the task within them.

## Fast Path and Closure

Use the direct fast path for questions and small or odd bounded tasks. This path
uses no workers or Deployment Token Report.

Before the final response that completes, pauses, or blocks a substantive
deployment, follow `~/.codex/codex_workflow/archivist.md` exactly once.
Update `agent_docs/project_diary.md` yourself when lasting decisions or lessons
change. Combine remaining documentation and handoff work in one Archivist
assignment when practical. Relay its handoff and exact six-column
`$deployment-token-report` table. Use a new ID for each later deployment.
